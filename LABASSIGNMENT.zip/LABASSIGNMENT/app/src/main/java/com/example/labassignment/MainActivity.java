package com.example.labassignment;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.*;


public class MainActivity extends AppCompatActivity {


    Spinner spinnerMonth;
    EditText etUnit;
    SeekBar seekRebate;
    TextView tvRebate, tvResult;
    Button btnCalculate;


    com.example.electricitybillapp.DatabaseHelper dbHelper;


    String[] months = {"January","February","March","April","May","June",
            "July","August","September","October","November","December"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        spinnerMonth = findViewById(R.id.spinnerMonth);
        etUnit = findViewById(R.id.etUnit);
        seekRebate = findViewById(R.id.seekRebate);
        tvRebate = findViewById(R.id.tvRebate);
        tvResult = findViewById(R.id.tvResult);
        btnCalculate = findViewById(R.id.btnCalculate);


        dbHelper = new com.example.electricitybillapp.DatabaseHelper(this);


        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, months);
        spinnerMonth.setAdapter(adapter);


        seekRebate.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @SuppressLint("SetTextI18n")
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvRebate.setText(progress + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });


        btnCalculate.setOnClickListener(v -> calculateAndSave());
    }


    @SuppressLint({"SetTextI18n", "DefaultLocale"})
    private void calculateAndSave() {
        if (etUnit.getText().toString().isEmpty()) {
            etUnit.setError("Please enter unit used");
            return;
        }


        int unit = Integer.parseInt(etUnit.getText().toString());
        if (unit < 1 || unit > 1000) {
            etUnit.setError("Unit must be between 1 and 1000");
            return;
        }


        int rebate = seekRebate.getProgress();
        double total = calculateBill(unit);
        double finalCost = total - (total * rebate / 100);


        tvResult.setText(
                "Total Charges: RM " + String.format("%.2f", total) +
                        "\nFinal Cost: RM " + String.format("%.2f", finalCost)
        );


        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("month", spinnerMonth.getSelectedItem().toString());
        cv.put("unit", unit);
        cv.put("total", total);
        cv.put("rebate", rebate);
        cv.put("final", finalCost);


        db.insert("bill", null, cv);
        Toast.makeText(this, "Data saved", Toast.LENGTH_SHORT).show();
    }


    private double calculateBill(int unit) {
        double total;
        if (unit <= 200)
            total = unit * 0.218;
        else if (unit <= 300)
            total = 200 * 0.218 + (unit - 200) * 0.334;
        else if (unit <= 600)
            total = 200 * 0.218 + 100 * 0.334 + (unit - 300) * 0.516;
        else
            total = 200 * 0.218 + 100 * 0.334 + 300 * 0.516 + (unit - 600) * 0.546;
        return total;
    }
}