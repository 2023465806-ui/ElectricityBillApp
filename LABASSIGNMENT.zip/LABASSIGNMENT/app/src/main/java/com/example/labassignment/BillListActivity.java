package com.example.electricitybillapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.*;

import java.util.ArrayList;

public class BillListActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> list = new ArrayList<>();
    ArrayList<Integer> ids = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill_list);

        listView = findViewById(R.id.listView);
        loadData();

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Intent i = new Intent(this, BillDetailActivity.class);
            i.putExtra("id", ids.get(position));
            startActivity(i);
        });
    }

    private void loadData() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM bill", null);

        list.clear();
        ids.clear();

        while (c.moveToNext()) {
            ids.add(c.getInt(0));
            list.add(c.getString(1) + " - RM " +
                    String.format("%.2f", c.getDouble(5)));
        }

        listView.setAdapter(new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, list));
    }
}