package com.example.electricitybillapp;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.*;

public class BillDetailActivity extends AppCompatActivity {

    TextView tvDetail;
    Button btnDelete;
    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill_detail);

        tvDetail = findViewById(R.id.tvDetail);
        btnDelete = findViewById(R.id.btnDelete);

        id = getIntent().getIntExtra("id", -1);
        loadDetail();

        btnDelete.setOnClickListener(v -> {
            DatabaseHelper dbHelper = new DatabaseHelper(this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            db.delete("bill", "id=?", new String[]{String.valueOf(id)});
            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void loadDetail() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM bill WHERE id=" + id, null);

        if (c.moveToFirst()) {
            tvDetail.setText(
                    "Month: " + c.getString(1) +
                            "\nUnit: " + c.getInt(2) +
                            "\nTotal Charges: RM " + c.getDouble(3) +
                            "\nRebate: " + c.getInt(4) + "%" +
                            "\nFinal Cost: RM " + c.getDouble(5)
            );
        }
    }
}